(Runtime evidence lands here when you run ArkEcho locally. Local only, never phoned home.)
